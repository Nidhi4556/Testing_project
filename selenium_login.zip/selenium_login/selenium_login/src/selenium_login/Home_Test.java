package selenium_login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Home_Test {
	
	public static void main(String[] args) {

		// Path of chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// URL of the login website that is tested
        String url = "file:///C:/Users/Administrator/Desktop/html/SIGN_UP_PAGE.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
        

        
}
}