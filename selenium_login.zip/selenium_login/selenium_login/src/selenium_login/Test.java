package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
//Importing required classes
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

//Main class
public class Test {

	// Main driver method
	public static void main(String[] args) {

		// Path of chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
//				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// URL of the login website that is tested
        String url = "file:///C:/Users/Administrator/Desktop/html/SIGN_UP_PAGE.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        
        /////////////////////////////////////   PART A END   ////////////////////////////////////////////////////
 
 
//        WebElement SignUp = driver.findElement(By.id("signUp"));
//        System.out.println("Clicking on the login element in the main page");
//        SignUp.click();
 
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
         WebElement FName = driver.findElement(By.id("firstName"));
        WebElement LName = driver.findElement(By.id("lastName"));   
        WebElement mgender = driver.findElement(By.id("male"));
        WebElement fgender = driver.findElement(By.id("female"));
        WebElement email = driver.findElement(By.id("email"));
        WebElement Cpassword = driver.findElement(By.id("password"));
        WebElement password = driver.findElement(By.id("confirmPassword"));
//        WebElement sign_up_Button = driver.findElement(By.id("signUp"));
        Actions builder = new Actions(driver);
        builder.moveToElement(FName).perform();
        
        FName.clear();
        System.out.println("Entering First Name");
        FName.sendKeys("Nidhi");
        
        LName.clear();
        System.out.println("Entering Last Name");
        LName.sendKeys("Trivedi");
        
//        fgender.clear();
        System.out.println("Entering Gender");
        fgender.sendKeys("Female");
        
        email.clear();
        System.out.println("Entering the email");
        email.sendKeys("trivedi4556@email.com");
 
        Cpassword.clear();
        System.out.println("Creating the password");
        Cpassword.sendKeys("password@123");
        
        password.clear();
        System.out.println("Confirming the password");
        password.sendKeys("password@123");
 
//        System.out.println("Clicking sign up button");
//        sign_up_Button.click();
 
        /*String title = "Welcome - LambdaTest";
 
        String actualTitle = driver.getTitle();
 
        System.out.println("Verifying the page title has started");
        Assert.assertEquals(actualTitle,title);
 
        System.out.println("The page title has been successfully verified");*/
 
        System.out.println("User logged in successfully");
 
//        driver.quit();

	}
}