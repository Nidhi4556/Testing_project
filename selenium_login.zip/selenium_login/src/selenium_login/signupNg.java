package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class signupNg {
	WebDriver driver;
  @Test
  public void f() {
	  WebElement signup = driver.findElement(By.id("signup-btn"));
      System.out.println("Clicking on the signup element in the main page");
      signup.click();

      driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);

      WebElement fname = driver.findElement(By.id("firstName"));
      WebElement lname = driver.findElement(By.id("lastName"));
      WebElement email = driver.findElement(By.id("email"));
      WebElement password = driver.findElement(By.id("password"));
      WebElement cpassword = driver.findElement(By.id("confirmPassword"));
      WebElement signupButton = driver.findElement(By.id("signup-btn"));
      Actions builder = new Actions(driver);
      builder.moveToElement(fname).perform();

      fname.clear();
      System.out.println("Entering first name");
      fname.sendKeys("Nidhi");
      
      lname.clear();
      System.out.println("Entering last name");
      lname.sendKeys("Trivedi");
      
      email.clear();
      System.out.println("Entering the email");
      email.sendKeys("trivedi4556@email.com");

      password.clear();
      System.out.println("entering the password");
      password.sendKeys("password@123");
      
      cpassword.clear();
      System.out.println("confirming the password");
      cpassword.sendKeys("password@123");

      System.out.println("Clicking signup button");
      signupButton.click();
  }
  @Test
  public void title() {
	  String title = "Sign Up";
	  
      String actualTitle = driver.getTitle();

      System.out.println("Verifying the page title has started");
      Assert.assertEquals(actualTitle,title);

      System.out.println("The page title has been successfully verified");


  }
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver.exe");
		driver = new ChromeDriver();

		// URL of the login website that is tested
      String url = "file:///C:/Users/Administrator/Downloads/sign_up.html";

      driver.get(url);
  }
  
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
