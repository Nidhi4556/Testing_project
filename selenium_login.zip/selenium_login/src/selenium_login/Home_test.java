package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Home_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver",
			"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		// URL of the login website that is tested
        String url = "file:///C:/Users/Administrator/Downloads/Home.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        
        /////////////////////////////////////   PART A END   ////////////////////////////////////////////////////
 
 
//        WebElement login = driver.findElement(By.id("login-btn"));
//        System.out.println("Clicking on the login element in the main page");
//        login.click();
// 
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
        
        WebElement loginButton = driver.findElement(By.id("login-button"));
        WebElement signupButton = driver.findElement(By.id("sign-up-button"));
        WebElement help = driver.findElement(By.id("footer-help"));
        WebElement about = driver.findElement(By.id("footer-about"));
        WebElement contact = driver.findElement(By.id("footer-contact"));
        
        System.out.println("Clicking on the login button");
        loginButton.click();
        
        System.out.println("Clicking on the signup button");
        signupButton.click();
        
        System.out.println("Clicking on the help button");
        help.click();
        
        System.out.println("Clicking on the about button");
        about.click();
        
        System.out.println("Clicking on the contact button");
        contact.click();
        
        String title = "Welcome On Board";
        
        String actualTitle = driver.getTitle();
 
        System.out.println("Verifying the page title has started");
        Assert.assertEquals(actualTitle,title);
 
        System.out.println("The page title has been successfully verified");

 
        driver.quit();


	}

}
