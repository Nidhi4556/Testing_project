package selenium_login;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;

public class loginNg {
	WebDriver driver;
  @Test
  public void elementTesting() {
	  WebElement login = driver.findElement(By.id("login-btn"));
      System.out.println("Clicking on the login element in the main page");
      login.click();

//      driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);

      WebElement email = driver.findElement(By.id("email"));
      WebElement password = driver.findElement(By.id("password"));
      WebElement loginButton = driver.findElement(By.id("login-btn"));
      Actions builder = new Actions(driver);
      builder.moveToElement(email).perform();

      email.clear();
      System.out.println("Entering the email");
      email.sendKeys("trivedi4556@email.com");

      password.clear();
      System.out.println("entering the password");
      password.sendKeys("password@123");

      System.out.println("Clicking login button");
      loginButton.click();

  }
  
  @Test
  public void title() {
	  String title = "Login Page";
	  
      String actualTitle = driver.getTitle();

      System.out.println("Verifying the page title has started");
      Assert.assertEquals(actualTitle,title);

      System.out.println("The page title has been successfully verified");


  }
  
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver.exe");
		driver = new ChromeDriver();

		// URL of the login website that is tested
      String url = "file:///C:/Users/Administrator/Downloads/log_in.html";

      driver.get(url);
  }
  

  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
